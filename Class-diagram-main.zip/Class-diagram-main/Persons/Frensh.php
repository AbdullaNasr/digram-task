<?php

include_once "Persons\Person.php";
class Frensh implements Person
{

    public function greet()
    {
        echo "Bonjour";
    }

}