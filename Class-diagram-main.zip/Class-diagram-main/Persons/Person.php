<?php

interface Person
{

    public function greet();

}